from lib.pages.p_accountDetailsValidation import accountDetailsValidation
from behave import *
import time
from nose.tools import *

@given(u'I navigate to the application "{url}"')
def step_impl(context,url):
    try:
        context.browser.get(url)
    except:
        raise EnvironmentError

@when(u'I enter account details')
def step_impl(context):
    accountDetails = accountDetailsValidation(context.browser)
    #Enter sort code and account number
    for row in context.table:
        sortCode = row['sortcode']
        accountNum = row['account']
        accountDetails.enterAccountDetails(sortCode, accountNum)
    accountDetails.clickValidateButton()
    time.sleep(2)

@then(u'the validator returns complete account details')
def step_impl(context):
    validAccDetails = accountDetailsValidation(context.browser)
    #Check for IBAN and Validation details
    ok_(validAccDetails.checkiBanDetailsDisplayed(),"IBAN details missing")
    ok_(validAccDetails.checkEISCDDataDisplayed(),"Validation details missing")

@then(u'the sort code error message prompts')
def step_impl(context):
    invalidSortCode = accountDetailsValidation(context.browser)
    #Check for sort code error message
    err = invalidSortCode.check_for_error_message()
    if err:
        return True
    else:
        ok_(err, "Sort code error message not displayed")

@then(u'he account number error message prompts')
def step_impl(context):
    invalidAccNum = accountDetailsValidation(context.browser)
    #Check for account number error message
    err = invalidAccNum.check_for_error_message()
    if err:
        return True
    else:
        ok_(err, "Account number error message not displayed")

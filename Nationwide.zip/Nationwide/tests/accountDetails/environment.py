from selenium import webdriver
import os, sys

def before_all(context):
    sys.path.append('..')
    sys.path.append(os.path.dirname(os.path.dirname(os.getcwd())))

def before_scenario(context, scenario):
    #At below argument send hosted chromedriver server path e.g. usr/bin/chromedriver
    context.browser = webdriver.Chrome('enter chromedriver path')

def after_scenario(context, scenario):
    context.browser.quit()

def after_all(context):
    pass
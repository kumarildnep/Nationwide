from lib.Base_Page_Object import Page
from lib.locators.l_sortCodes import sortCodesLocators
from selenium.common.exceptions import NoSuchElementException

class accountDetailsValidation(Page):

    def enterAccountDetails(self, sortCode, accNum):
        self.find_element(sortCodesLocators.typeSortCode).send_keys(sortCode)
        self.find_element(sortCodesLocators.typeAccountNumber).send_keys(accNum)
        return True

    def clickValidateButton(self):
        self.find_element(sortCodesLocators.validateButton).click()
        return True

    def checkiBanDetailsDisplayed(self):
        try:
            self.element = self.find_element(sortCodesLocators.ibanDetails)
            return self.element.is_displayed()
        except:
            raise NoSuchElementException


    def checkEISCDDataDisplayed(self):
        try:
            self.element = self.find_element(sortCodesLocators.validationDetails)
            return self.element.is_displayed()
        except:
            raise NoSuchElementException
from selenium.webdriver.common.by import By

class sortCodesLocators(object):
    typeSortCode = (By.XPATH, '//fieldset//input[@placeholder="Type Sort Code"]')
    typeAccountNumber = (By.XPATH, '//fieldset//input[@placeholder="Type Account Number"]')
    validateButton = (By.XPATH, '//fieldset//input[@type="submit"]')
    ibanDetails = (By.ID, 'ibandetailstable')
    validationDetails = (By.XPATH, '//th[text()="Validation Details ( EISCD Data )"]')

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, NoSuchWindowException, TimeoutException

class Page(object):
    "Base class that all page models can inherit"
    def __init__(self, selenium_driver):
        self.driver = selenium_driver
        self.timeout = 8

    def find_element(self,loc, timeout=8):
        try:
            self.element = WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located(loc))
            return self.element
        except:
            raise NoSuchElementException

    def check_for_error_message(self):
        # Checks for alert-danger block and returns text if present (False if not)
        try:
            self.element=self.find_element((By.CLASS_NAME,'alert alert-danger'),2)
            return self.element.text
        except:
            return False